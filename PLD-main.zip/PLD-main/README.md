# PLD
Creat Symantic of same Statmentof Programming Language
Creating Same Statment Such as If Statment ,If ..else Statment , for Statment , Switch Statment and While Statment .
This Sentences has been validated by GoldParserEngine and Window form Application (I creat This).
